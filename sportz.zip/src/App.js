import logo from './logo.svg';
import './App.css';
import PlayerList from './UserData/PlayerLIst'

function App() {
    return (<div >
        
        <PlayerList/>
    </div>
    );
}
export default App;